import { NavLink } from "react-router-dom";
function NavBar() {
  return (
    <header className="navbar">
      <div className="navbar-logo">Language App</div>
      <nav className="navbar-links">
        <NavLink to="/">Головна</NavLink>
        <NavLink to="/words">Слова</NavLink>
        <NavLink to="/learn">Картки</NavLink>
        <NavLink to="/quiz">Тест</NavLink>
        <NavLink to="/stats">Статистика</NavLink>
      </nav>
    </header>
  );
}
export default NavBar;
