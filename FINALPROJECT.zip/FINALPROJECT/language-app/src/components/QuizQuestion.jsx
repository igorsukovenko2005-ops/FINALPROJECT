function QuizQuestion({ question, options, onAnswer }) {
  return (
    <div className="quiz-question">
      <h3>Переклад слова: {question.term}</h3>
      <div className="quiz-options">
        {options.map((opt) => (
          <button key={opt} onClick={() => onAnswer(opt)}>
            {opt}
          </button>
        ))}
      </div>
    </div>
  );
}
export default QuizQuestion;
