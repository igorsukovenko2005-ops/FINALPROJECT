function WordCard({ word, showTranslation, onToggleShow, onKnow }) {
  return (
    <div className="word-card">
      <h3>{word.term}</h3>

      {showTranslation && (
        <>
          <p className="translation">{word.translation}</p>
          {word.example && <p className="example">{word.example}</p>}
        </>
      )}

      <button onClick={onToggleShow}>
        {showTranslation ? "Сховати переклад" : "Показати переклад"}
      </button>

      <div className="card-actions">
        <button onClick={onKnow}>Позначити як вивчене</button>
      </div>
    </div>
  );
}
export default WordCard;