import { useState } from "react";
function WordForm({ onAdd }) {
  const [term, setTerm] = useState("");
  const [translation, setTranslation] = useState("");
  const [example, setExample] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!term.trim() || !translation.trim()) {
      alert("Слово і переклад обовʼязкові");
      return;
    }
    onAdd({
      term: term.trim(),
      translation: translation.trim(),
      example: example.trim(),
    });
    setTerm("");
    setTranslation("");
    setExample("");
  };
  return (
    <form className="word-form" onSubmit={handleSubmit}>
      <h3>Додати слово</h3>
      <input
        type="text"
        placeholder="Слово (англійською)"
        value={term}
        onChange={(e) => setTerm(e.target.value)}
      />
      <input
        type="text"
        placeholder="Переклад"
        value={translation}
        onChange={(e) => setTranslation(e.target.value)}
      />
      <input
        type="text"
        placeholder="Приклад речення (необовʼязково)"
        value={example}
        onChange={(e) => setExample(e.target.value)}
      />
      <button type="submit">Додати</button>
    </form>
  );
}
export default WordForm;
