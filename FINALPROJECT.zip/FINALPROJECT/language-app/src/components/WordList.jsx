function WordList({ words, onDelete }) {
  if (words.length === 0) {
    return <p>Список слів порожній. Додай перше слово!</p>;
  }
  return (
    <table className="word-table">
      <thead>
        <tr>
          <th>Слово</th>
          <th>Переклад</th>
          <th>Приклад</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {words.map((w) => (
          <tr key={w.id}>
            <td>{w.term}</td>
            <td>{w.translation}</td>
            <td>{w.example}</td>
            <td>
              <button onClick={() => onDelete(w.id)}>🗑</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
export default WordList;
