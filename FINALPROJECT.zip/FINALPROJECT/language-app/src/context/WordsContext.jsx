import { createContext, useContext, useEffect, useState } from "react";
const WordsContext = createContext();
const STORAGE_KEY_WORDS = "language_app_words_v1";
const STORAGE_KEY_STATS = "language_app_stats_v1";
const defaultWords = [
  { id: 1, term: "apple", translation: "яблуко", example: "I eat an apple.", learned: false },
  { id: 2, term: "improve", translation: "покращувати", example: "I want to improve my English.", learned: false },
];
const defaultStats = {
  quizAttempts: 0,
  quizCorrect: 0,
};
export function WordsProvider({ children }) {
  const [words, setWords] = useState([]);
  const [stats, setStats] = useState(defaultStats);
  useEffect(() => {
    const storedWords = localStorage.getItem(STORAGE_KEY_WORDS);
    if (storedWords) {
      setWords(JSON.parse(storedWords));
    } else {
      setWords(defaultWords);
    }
    const storedStats = localStorage.getItem(STORAGE_KEY_STATS);
    if (storedStats) {
      setStats(JSON.parse(storedStats));
    } else {
      setStats(defaultStats);
    }
  }, []);
  useEffect(() => {
    if (words.length > 0) {
      localStorage.setItem(STORAGE_KEY_WORDS, JSON.stringify(words));
    }
  }, [words]);
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_STATS, JSON.stringify(stats));
  }, [stats]);

  const addWord = (word) => {
    setWords((prev) => [...prev, { ...word, id: Date.now(), learned: false }]);
  };
  const deleteWord = (id) => {
    setWords((prev) => prev.filter((w) => w.id !== id));
  };
  const markLearned = (id) => {
    setWords((prev) =>
      prev.map((w) => (w.id === id ? { ...w, learned: true } : w))
    );
  };
  const recordQuizResult = (correctAnswers) => {
    setStats((prev) => ({
      ...prev,
      quizAttempts: prev.quizAttempts + 1,
      quizCorrect: prev.quizCorrect + correctAnswers,
    }));
  };
  const value = { words, stats, addWord, deleteWord, markLearned, recordQuizResult };
  return <WordsContext.Provider value={value}>{children}</WordsContext.Provider>;
}
export function useWords() {
  const ctx = useContext(WordsContext);
  if (!ctx) throw new Error("useWords must be used within WordsProvider");
  return ctx;
}