import { useWords } from "../context/WordsContext";
function HomePage() {
  const { words } = useWords();
  const learnedCount = words.filter((w) => w.learned).length;
  return (
    <section className="page">
      <h1>Language Learning App</h1>
      <p>Простий SPA-додаток для вивчення слів.</p>
      <ul>
        <li>Додавай свої слова на сторінці <b>“Слова”</b>.</li>
        <li>Повторюй їх у режимі <b>“Картки”</b>.</li>
      </ul>
      <p>
        У словнику зараз <b>{words.length}</b> слів, з них позначено як вивчені:{" "}
        <b>{learnedCount}</b>.
      </p>
    </section>
  );
}
export default HomePage;
