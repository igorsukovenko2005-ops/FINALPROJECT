import { useState } from "react";
import { useWords } from "../context/WordsContext";
import WordCard from "../components/WordCard";
function LearnPage() {
  const { words, markLearned } = useWords();
  const [index, setIndex] = useState(0);
  const [showTranslation, setShowTranslation] = useState(false);
  if (words.length === 0) {
    return (
      <section className="page">
        <h2>Картки</h2>
        <p>Немає слів для вивчення. Додай їх на сторінці “Слова”.</p>
      </section>
    );
  }
  const current = words[index];
  const nextCard = () => {
    setShowTranslation(false);
    setIndex((prev) => (prev + 1) % words.length);
  };

  const handleKnow = () => {
    markLearned(current.id);
    nextCard();
  };
  return (
    <section className="page">
      <h2>Картки</h2>
      <WordCard
        word={current}
        showTranslation={showTranslation}
        onToggleShow={() => setShowTranslation((v) => !v)}
        onKnow={handleKnow}
      />
      <p>
        Картка {index + 1} / {words.length}
      </p>
    </section>
  );
}
export default LearnPage;