import { useEffect, useState } from "react";
import { useWords } from "../context/WordsContext";
import QuizQuestion from "../components/QuizQuestion";
function QuizPage() {
  const { words, recordQuizResult } = useWords();
  const [questions, setQuestions] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  useEffect(() => {
    if (words.length >= 4) {
      const shuffled = [...words].sort(() => Math.random() - 0.5);
      const selected = shuffled.slice(0, 5);
      setQuestions(selected);
    }
  }, [words]);
  if (words.length < 4) {
    return (
      <section className="page">
        <h2>Тест</h2>
        <p>Для тесту потрібно принаймні 4 слова у словнику.</p>
      </section>
    );
  }
  if (!questions.length) return null;
  const currentWord = questions[currentIndex];
  const buildOptions = () => {
    const incorrect = words
      .filter((w) => w.id !== currentWord.id)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map((w) => w.translation);

    const options = [...incorrect, currentWord.translation].sort(
      () => Math.random() - 0.5
    );
    return options;
  };
  const handleAnswer = (answer) => {
    const isCorrect = answer === currentWord.translation;
    if (isCorrect) setCorrectCount((c) => c + 1);

    if (currentIndex + 1 >= questions.length) {
      setFinished(true);
      recordQuizResult(isCorrect ? correctCount + 1 : correctCount);
    } else {
      setCurrentIndex((i) => i + 1);
    }
  };
  if (finished) {
    return (
      <section className="page">
        <h2>Результат тесту</h2>
        <p>
          Правильних відповідей: {correctCount} з {questions.length}
        </p>
        <p>Результат збережено в статистику.</p>
      </section>
    );
  }
  return (
    <section className="page">
      <h2>Тест</h2>
      <QuizQuestion
        question={currentWord}
        options={buildOptions()}
        onAnswer={handleAnswer}
      />
      <p>
        Питання {currentIndex + 1} / {questions.length}
      </p>
    </section>
  );
}
export default QuizPage;