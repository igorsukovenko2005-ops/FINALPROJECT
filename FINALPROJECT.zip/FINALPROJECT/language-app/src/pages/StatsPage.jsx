import { useWords } from "../context/WordsContext";
function StatsPage() {
  const { words, stats } = useWords();
  const totalWords = words.length;
  const learnedCount = words.filter((w) => w.learned).length;
  const learnedPercent =
    totalWords > 0 ? Math.round((learnedCount / totalWords) * 100) : 0;
  return (
    <section className="page">
      <h2>Статистика прогресу</h2>
      <ul className="stats-list">
        <li>
          Всього слів у словнику: <b>{totalWords}</b>
        </li>
        <li>
          Позначено як вивчені: <b>{learnedCount}</b> ({learnedPercent}%)
        </li>
        <li>
          Кількість пройдених тестів: <b>{stats.quizAttempts}</b>
        </li>
        <li>
          Правильних відповідей (загалом): <b>{stats.quizCorrect}</b>
        </li>
      </ul>
    </section>
  );
}
export default StatsPage;