import { useWords } from "../context/WordsContext";
import WordForm from "../components/WordForm";
import WordList from "../components/WordList";

function WordsPage() {
  const { words, addWord, deleteWord } = useWords();

  return (
    <section className="page">
      <h2>Слова</h2>
      <div className="words-layout">
        <WordForm onAdd={addWord} />
        <WordList words={words} onDelete={deleteWord} />
      </div>
    </section>
  );
}

export default WordsPage;
